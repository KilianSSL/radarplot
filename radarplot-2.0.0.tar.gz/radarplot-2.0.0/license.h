/* $Id: license.h,v 1.1 2005/05/15 06:35:37 ecd Exp $
 */

#ifndef _LICENSE_H
#define _LICENSE_H 1

extern const char gnu_general_public_license[];

#endif /* !(_LICENSE_H) */
