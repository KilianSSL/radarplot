/* $Id: register.h,v 1.1 2005/05/15 10:17:21 ecd Exp $
 */

#ifndef _REGISTER_H
#define _REGISTER_H 1

extern int verify_registration_file(const char *pathname, GKeyFile **license);

#endif /* !(_REGISTER_H) */
